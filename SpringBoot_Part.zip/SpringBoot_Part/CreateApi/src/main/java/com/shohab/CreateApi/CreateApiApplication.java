package com.shohab.CreateApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreateApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreateApiApplication.class, args);
	}

}
